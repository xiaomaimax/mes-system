-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: 192.168.100.6    Database: mes_system
-- ------------------------------------------------------
-- Server version	8.0.45-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `username` varchar(50) NOT NULL,
  `action` varchar(100) NOT NULL COMMENT '操作类型',
  `resource_type` varchar(50) DEFAULT NULL COMMENT '资源类型',
  `resource_id` int DEFAULT NULL COMMENT '资源 ID',
  `ip_address` varchar(50) DEFAULT NULL COMMENT 'IP 地址',
  `user_agent` text COMMENT '用户代理',
  `request_data` json DEFAULT NULL COMMENT '请求数据',
  `response_status` int DEFAULT NULL COMMENT '响应状态',
  `error_message` text COMMENT '错误信息',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_action` (`action`),
  KEY `idx_resource_type` (`resource_type`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='审计日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,1,'admin','USER_ROLE_ASSIGN',NULL,NULL,'::1','curl/8.5.0','{\"roleIds\": [1]}',200,NULL,'2026-03-27 06:08:02'),(2,1,'admin','DATA_PERMISSION_UPDATE',NULL,NULL,'::1','curl/8.5.0','{\"role_id\": 2, \"can_edit\": true, \"can_view\": true, \"scope_type\": \"DEPARTMENT\", \"resource_type\": \"production_order\"}',200,NULL,'2026-03-27 06:14:07');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batch_tracing`
--

DROP TABLE IF EXISTS `batch_tracing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `batch_tracing` (
  `id` int NOT NULL AUTO_INCREMENT,
  `batch_number` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `production_date` date DEFAULT NULL,
  `iqc_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pqc_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fqc_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oqc_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `overall_status` enum('qualified','unqualified','pending') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `batch_number` (`batch_number`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch_tracing`
--

LOCK TABLES `batch_tracing` WRITE;
/*!40000 ALTER TABLE `batch_tracing` DISABLE KEYS */;
INSERT INTO `batch_tracing` VALUES (1,'B20241228001','Phone Case A','2024-12-28','qualified','qualified','qualified','qualified','qualified',NULL,'2026-01-15 02:26:24','2026-01-15 02:26:24'),(2,'B20241227001','Phone Case B','2024-12-27','qualified','qualified','qualified','qualified','qualified',NULL,'2026-01-15 02:26:24','2026-01-15 02:26:24'),(3,'B20241226001','Charger','2024-12-26','qualified','qualified','qualified','qualified','qualified',NULL,'2026-01-15 02:26:24','2026-01-15 02:26:24'),(4,'B20241225001','Plastic Cup Type A','2024-12-25','qualified','unqualified','unqualified','unqualified','unqualified',NULL,'2026-01-15 02:26:24','2026-01-15 02:26:24');
/*!40000 ALTER TABLE `batch_tracing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_permissions`
--

DROP TABLE IF EXISTS `data_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `data_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `role_id` int NOT NULL,
  `resource_type` varchar(50) NOT NULL COMMENT '资源类型',
  `scope_type` enum('ALL','DEPARTMENT','SELF','CUSTOM') NOT NULL COMMENT '数据范围类型',
  `scope_value` text COMMENT '数据范围值（JSON 格式）',
  `can_view` tinyint(1) DEFAULT '1',
  `can_edit` tinyint(1) DEFAULT '0',
  `can_delete` tinyint(1) DEFAULT '0',
  `can_export` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_role_resource` (`role_id`,`resource_type`),
  KEY `idx_role_id` (`role_id`),
  KEY `idx_resource_type` (`resource_type`),
  CONSTRAINT `data_permissions_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='数据权限表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_permissions`
--

LOCK TABLES `data_permissions` WRITE;
/*!40000 ALTER TABLE `data_permissions` DISABLE KEYS */;
INSERT INTO `data_permissions` VALUES (1,2,'production_order','DEPARTMENT',NULL,1,1,0,0,'2026-03-27 06:14:07','2026-03-27 06:14:07');
/*!40000 ALTER TABLE `data_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `defect_reasons`
--

DROP TABLE IF EXISTS `defect_reasons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `defect_reasons` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reason_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` enum('enabled','disabled') COLLATE utf8mb4_unicode_ci DEFAULT 'enabled',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reason_id` (`reason_id`),
  UNIQUE KEY `reason_code` (`reason_code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `defect_reasons`
--

LOCK TABLES `defect_reasons` WRITE;
/*!40000 ALTER TABLE `defect_reasons` DISABLE KEYS */;
INSERT INTO `defect_reasons` VALUES (1,'DR-001','DR001','Size deviation','Process issue','Product size does not meet specification','enabled','2026-01-15 02:26:24','2026-01-15 02:26:24'),(2,'DR-002','DR002','Surface scratch','Appearance issue','Product surface has scratches','enabled','2026-01-15 02:26:24','2026-01-15 02:26:24'),(3,'DR-003','DR003','Function abnormal','Function issue','Product function is abnormal','enabled','2026-01-15 02:26:24','2026-01-15 02:26:24'),(4,'DR-004','DR004','Color mismatch','Appearance issue','Product color does not match specification','enabled','2026-01-15 02:26:24','2026-01-15 02:26:24'),(5,'DR-005','DR005','Assembly error','Assembly issue','Product assembly is incorrect','enabled','2026-01-15 02:26:24','2026-01-15 02:26:24');
/*!40000 ALTER TABLE `defect_reasons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `defect_records`
--

DROP TABLE IF EXISTS `defect_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `defect_records` (
  `id` int NOT NULL AUTO_INCREMENT,
  `record_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch_number` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `defect_date` date NOT NULL,
  `defect_reason` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `defect_qty` int NOT NULL,
  `severity` enum('minor','normal','critical') COLLATE utf8mb4_unicode_ci DEFAULT 'normal',
  `status` enum('resolved','in_progress','pending') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `record_id` (`record_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `defect_records`
--

LOCK TABLES `defect_records` WRITE;
/*!40000 ALTER TABLE `defect_records` DISABLE KEYS */;
INSERT INTO `defect_records` VALUES (1,'DEF-001','B20241218001','Plastic Cup Type A','2024-12-18','Size deviation',50,'critical','resolved',NULL,'2026-01-15 02:26:24','2026-01-15 02:26:24'),(2,'DEF-002','B20241218002','Box Type B','2024-12-18','Surface scratch',20,'minor','resolved',NULL,'2026-01-15 02:26:24','2026-01-15 02:26:24'),(3,'DEF-003','B20241217001','Phone Case A','2024-12-17','Color mismatch',15,'normal','resolved',NULL,'2026-01-15 02:26:24','2026-01-15 02:26:24'),(4,'DEF-004','B20241216001','Charger','2024-12-16','Function abnormal',8,'critical','resolved',NULL,'2026-01-15 02:26:24','2026-01-15 02:26:24');
/*!40000 ALTER TABLE `defect_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dept_code` varchar(50) NOT NULL COMMENT '部门代码',
  `dept_name` varchar(100) NOT NULL COMMENT '部门名称',
  `parent_id` int DEFAULT NULL COMMENT '父部门 ID',
  `manager_id` int DEFAULT NULL COMMENT '部门负责人 ID',
  `is_active` tinyint(1) DEFAULT '1' COMMENT '是否启用',
  `sort_order` int DEFAULT '0' COMMENT '排序',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dept_code` (`dept_code`),
  KEY `manager_id` (`manager_id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_dept_code` (`dept_code`),
  CONSTRAINT `departments_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `departments_ibfk_2` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='部门表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES (1,'HQ','总部',NULL,NULL,1,0,'2026-03-26 03:25:12','2026-03-26 03:25:12'),(2,'PROD','生产部',1,NULL,1,1,'2026-03-26 03:25:12','2026-03-26 03:25:12'),(3,'QUALITY','质量部',1,NULL,1,2,'2026-03-26 03:25:12','2026-03-26 03:25:12'),(4,'WAREHOUSE','仓库',1,NULL,1,3,'2026-03-26 03:25:12','2026-03-26 03:25:12'),(5,'MAINTENANCE','设备部',1,NULL,1,4,'2026-03-26 03:25:12','2026-03-26 03:25:12'),(6,'IT','IT 部',1,NULL,1,5,'2026-03-26 03:25:12','2026-03-26 03:25:12'),(7,'PROD_LINE1','一车间',2,NULL,1,1,'2026-03-26 03:25:12','2026-03-26 03:25:12'),(8,'PROD_LINE2','二车间',2,NULL,1,2,'2026-03-26 03:25:12','2026-03-26 03:25:12');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `devices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `device_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('running','stopped','maintenance','fault') COLLATE utf8mb4_unicode_ci DEFAULT 'stopped',
  `production_line_id` int DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_device_code` (`device_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devices`
--

LOCK TABLES `devices` WRITE;
/*!40000 ALTER TABLE `devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipment`
--

DROP TABLE IF EXISTS `equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `equipment_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `equipment_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `equipment_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `production_line_id` int NOT NULL,
  `status` enum('running','idle','maintenance','fault','offline') COLLATE utf8mb4_unicode_ci DEFAULT 'idle',
  `location` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `manufacturer` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `warranty_end_date` date DEFAULT NULL,
  `last_maintenance_date` date DEFAULT NULL,
  `next_maintenance_date` date DEFAULT NULL,
  `specifications` json DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `equipment_code` (`equipment_code`),
  KEY `production_line_id` (`production_line_id`),
  CONSTRAINT `equipment_ibfk_1` FOREIGN KEY (`production_line_id`) REFERENCES `production_lines` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment`
--

LOCK TABLES `equipment` WRITE;
/*!40000 ALTER TABLE `equipment` DISABLE KEYS */;
INSERT INTO `equipment` VALUES (1,'EQ-001','注塑机A1','注塑设备',1,'running','车间A-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-01-15 02:19:27','2026-01-15 02:19:27'),(2,'EQ-002','包装机B1','包装设备',1,'idle','车间A-02',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-01-15 02:19:27','2026-01-15 02:19:27'),(3,'EQ-003','检测设备C1','检测设备',2,'maintenance','车间B-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-01-15 02:19:27','2026-01-15 02:19:27'),(4,'EQ-004','传送带D1','传送设备',3,'running','车间C-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-01-15 02:19:27','2026-01-15 02:19:27');
/*!40000 ALTER TABLE `equipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipment_scheduling_ext`
--

DROP TABLE IF EXISTS `equipment_scheduling_ext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipment_scheduling_ext` (
  `id` int NOT NULL AUTO_INCREMENT,
  `equipment_id` int NOT NULL,
  `capacity_per_hour` int DEFAULT '0',
  `scheduling_weight` int DEFAULT '50',
  `is_available_for_scheduling` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `equipment_id` (`equipment_id`),
  CONSTRAINT `equipment_scheduling_ext_ibfk_1` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment_scheduling_ext`
--

LOCK TABLES `equipment_scheduling_ext` WRITE;
/*!40000 ALTER TABLE `equipment_scheduling_ext` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipment_scheduling_ext` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fqc_inspections`
--

DROP TABLE IF EXISTS `fqc_inspections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fqc_inspections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `inspection_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch_number` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `inspection_date` date NOT NULL,
  `inspector` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `inspection_qty` int NOT NULL,
  `qualified_qty` int NOT NULL,
  `pass_rate` decimal(5,2) DEFAULT NULL,
  `inspection_result` enum('qualified','unqualified','pending') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `status` enum('completed','in_progress','pending') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inspection_id` (`inspection_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fqc_inspections`
--

LOCK TABLES `fqc_inspections` WRITE;
/*!40000 ALTER TABLE `fqc_inspections` DISABLE KEYS */;
INSERT INTO `fqc_inspections` VALUES (1,'FQC-2024-001','B20241228001','Phone Case A','2024-12-28','Inspector Wang',1000,990,99.00,'qualified','completed',NULL,'2026-01-15 02:26:24','2026-01-15 02:26:24'),(2,'FQC-2024-002','B20241227001','Phone Case B','2024-12-27','Inspector Zhao',1200,1188,99.00,'qualified','completed',NULL,'2026-01-15 02:26:24','2026-01-15 02:26:24'),(3,'FQC-2024-003','B20241226001','Charger','2024-12-26','Inspector Sun',800,792,99.00,'qualified','completed',NULL,'2026-01-15 02:26:24','2026-01-15 02:26:24');
/*!40000 ALTER TABLE `fqc_inspections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inspection_standards`
--

DROP TABLE IF EXISTS `inspection_standards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inspection_standards` (
  `id` int NOT NULL AUTO_INCREMENT,
  `standard_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `standard_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `standard_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('enabled','disabled') COLLATE utf8mb4_unicode_ci DEFAULT 'enabled',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `standard_id` (`standard_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inspection_standards`
--

LOCK TABLES `inspection_standards` WRITE;
/*!40000 ALTER TABLE `inspection_standards` DISABLE KEYS */;
INSERT INTO `inspection_standards` VALUES (1,'STD-001','Phone Case A','STD-001','Phone Case A Inspection Standard','V2.1','enabled','2026-01-15 02:26:24','2026-01-15 02:26:24'),(2,'STD-002','Charger','STD-002','Charger Inspection Standard','V1.0','enabled','2026-01-15 02:26:24','2026-01-15 02:26:24'),(3,'STD-003','Phone Case B','STD-003','Phone Case B Inspection Standard','V1.5','enabled','2026-01-15 02:26:24','2026-01-15 02:26:24'),(4,'STD-004','Raw Material A','STD-004','Raw Material A Inspection Standard','V3.0','enabled','2026-01-15 02:26:24','2026-01-15 02:26:24');
/*!40000 ALTER TABLE `inspection_standards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory` (
  `id` int NOT NULL AUTO_INCREMENT,
  `material_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `material_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `material_type` enum('raw_material','semi_finished','finished_product') COLLATE utf8mb4_unicode_ci NOT NULL,
  `current_stock` decimal(10,2) NOT NULL DEFAULT '0.00',
  `min_stock` decimal(10,2) NOT NULL DEFAULT '0.00',
  `max_stock` decimal(10,2) NOT NULL DEFAULT '0.00',
  `unit` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit_price` decimal(10,2) DEFAULT NULL,
  `location` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplier` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_updated` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `material_code` (`material_code`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
INSERT INTO `inventory` VALUES (1,'MAT-001','原料A','raw_material',1500.00,500.00,3000.00,'kg',NULL,'仓库A-01',NULL,'2026-01-15 02:19:27','2026-01-15 02:19:27','2026-01-15 02:19:27'),(2,'MAT-002','原料B','raw_material',800.00,300.00,2000.00,'kg',NULL,'仓库A-02',NULL,'2026-01-15 02:19:27','2026-01-15 02:19:27','2026-01-15 02:19:27'),(3,'MAT-003','包装材料','raw_material',2000.00,1000.00,5000.00,'个',NULL,'仓库B-01',NULL,'2026-01-15 02:19:27','2026-01-15 02:19:27','2026-01-15 02:19:27'),(4,'PROD-A001','产品A','finished_product',500.00,100.00,1000.00,'个',NULL,'成品仓库-01',NULL,'2026-01-15 02:19:27','2026-01-15 02:19:27','2026-01-15 02:19:27'),(5,'PROD-B001','产品B','finished_product',300.00,50.00,800.00,'个',NULL,'成品仓库-02',NULL,'2026-01-15 02:19:27','2026-01-15 02:19:27','2026-01-15 02:19:27');
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_transactions`
--

DROP TABLE IF EXISTS `inventory_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_transactions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `material_id` int NOT NULL,
  `transaction_type` enum('in','out','adjust') COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `reference_type` enum('purchase','production','sale','adjustment') COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference_id` int DEFAULT NULL,
  `operator_id` int NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `transaction_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `material_id` (`material_id`),
  KEY `operator_id` (`operator_id`),
  CONSTRAINT `inventory_transactions_ibfk_1` FOREIGN KEY (`material_id`) REFERENCES `inventory` (`id`),
  CONSTRAINT `inventory_transactions_ibfk_2` FOREIGN KEY (`operator_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_transactions`
--

LOCK TABLES `inventory_transactions` WRITE;
/*!40000 ALTER TABLE `inventory_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `iqc_inspections`
--

DROP TABLE IF EXISTS `iqc_inspections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `iqc_inspections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `inspection_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purchase_order` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `material_info` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `arrival_date` date NOT NULL,
  `inspection_date` date NOT NULL,
  `inspector` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `inspection_qty` int NOT NULL,
  `qualified_qty` int NOT NULL,
  `defect_type` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comprehensive_score` decimal(5,2) DEFAULT NULL,
  `inspection_result` enum('qualified','unqualified','pending') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `status` enum('completed','in_progress','pending') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inspection_id` (`inspection_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iqc_inspections`
--

LOCK TABLES `iqc_inspections` WRITE;
/*!40000 ALTER TABLE `iqc_inspections` DISABLE KEYS */;
INSERT INTO `iqc_inspections` VALUES (1,'IQC-2024-001','PO-2024-001','Supplier A','Raw Material A','2024-12-28','2024-12-28','Inspector Zhang',100,98,'Size deviation',95.00,'qualified','completed',NULL,'2026-01-15 02:26:24','2026-01-15 02:26:24'),(2,'IQC-2024-002','PO-2024-002','Supplier B','Raw Material B','2024-12-27','2024-12-27','Inspector Li',150,148,'Surface scratch',98.00,'qualified','completed',NULL,'2026-01-15 02:26:24','2026-01-15 02:26:24'),(3,'IQC-2024-003','PO-2024-003','Supplier C','Packaging Material','2024-12-26','2024-12-26','Inspector Wang',500,495,'Defect',99.00,'qualified','completed',NULL,'2026-01-15 02:26:24','2026-01-15 02:26:24');
/*!40000 ALTER TABLE `iqc_inspections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `material_batches`
--

DROP TABLE IF EXISTS `material_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `material_batches` (
  `id` int NOT NULL AUTO_INCREMENT,
  `batch_number` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `material_id` int NOT NULL,
  `supplier_id` int DEFAULT NULL,
  `quantity` int NOT NULL,
  `remaining_quantity` int DEFAULT NULL,
  `unit` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `production_date` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `receipt_date` date NOT NULL,
  `quality_status` enum('pending','passed','failed','conditional') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `inspection_report` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `storage_location` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','used_up','expired','returned','scrapped') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_batch_no` (`batch_number`),
  KEY `idx_material` (`material_id`),
  KEY `idx_supplier` (`supplier_id`),
  KEY `idx_status` (`status`),
  KEY `idx_expiry` (`expiry_date`),
  CONSTRAINT `fk_batch_material` FOREIGN KEY (`material_id`) REFERENCES `materials` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_batch_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_batches`
--

LOCK TABLES `material_batches` WRITE;
/*!40000 ALTER TABLE `material_batches` DISABLE KEYS */;
INSERT INTO `material_batches` VALUES (1,'BATCH-20260101-001',1,1,150,130,'张','2026-01-01',NULL,'2026-01-05','passed',NULL,NULL,'active',NULL,'2026-03-26 06:03:20','2026-03-26 06:03:20'),(2,'BATCH-20260105-001',2,1,200,180,'张','2026-01-05',NULL,'2026-01-08','passed',NULL,NULL,'active',NULL,'2026-03-26 06:03:20','2026-03-26 06:03:20'),(3,'BATCH-20260110-001',3,2,800,700,'KG','2026-01-10',NULL,'2026-01-12','passed',NULL,NULL,'active',NULL,'2026-03-26 06:03:20','2026-03-26 06:03:20');
/*!40000 ALTER TABLE `material_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `material_bom`
--

DROP TABLE IF EXISTS `material_bom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `material_bom` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parent_material_id` int NOT NULL,
  `child_material_id` int NOT NULL,
  `quantity` decimal(10,4) NOT NULL DEFAULT '1.0000',
  `unit` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loss_rate` decimal(5,4) DEFAULT '0.0000',
  `sort_order` int DEFAULT '0',
  `effective_date` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `version` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '1.0',
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_bom_unique` (`parent_material_id`,`child_material_id`,`version`),
  KEY `idx_parent` (`parent_material_id`),
  KEY `idx_child` (`child_material_id`),
  CONSTRAINT `fk_bom_child` FOREIGN KEY (`child_material_id`) REFERENCES `materials` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_bom_parent` FOREIGN KEY (`parent_material_id`) REFERENCES `materials` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_bom`
--

LOCK TABLES `material_bom` WRITE;
/*!40000 ALTER TABLE `material_bom` DISABLE KEYS */;
INSERT INTO `material_bom` VALUES (3,1,3,2.5000,'KG',0.0500,0,NULL,NULL,'1.0',NULL,'2026-03-26 06:03:20','2026-03-26 06:03:20');
/*!40000 ALTER TABLE `material_bom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `material_categories`
--

DROP TABLE IF EXISTS `material_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `material_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` int DEFAULT NULL,
  `level` int DEFAULT '1',
  `path` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `sort_order` int DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_category_code` (`category_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_categories`
--

LOCK TABLES `material_categories` WRITE;
/*!40000 ALTER TABLE `material_categories` DISABLE KEYS */;
INSERT INTO `material_categories` VALUES (1,'CAT-RAW','原材料',NULL,1,'/CAT-RAW',NULL,0,1,'2026-03-26 05:57:19','2026-03-26 05:57:19'),(2,'CAT-RAW-001','钢材',1,2,'/CAT-RAW/CAT-RAW-001',NULL,0,1,'2026-03-26 05:57:19','2026-03-26 05:57:19'),(3,'CAT-RAW-002','塑料',1,2,'/CAT-RAW/CAT-RAW-002',NULL,0,1,'2026-03-26 05:57:19','2026-03-26 05:57:19');
/*!40000 ALTER TABLE `material_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `material_device_relations`
--

DROP TABLE IF EXISTS `material_device_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `material_device_relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `material_id` int NOT NULL,
  `device_id` int NOT NULL,
  `relation_type` varchar(50) DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `weight` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_material_device` (`material_id`,`device_id`,`relation_type`),
  KEY `fk_mdr_device` (`device_id`),
  CONSTRAINT `fk_mdr_device` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mdr_material` FOREIGN KEY (`material_id`) REFERENCES `materials` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_device_relations`
--

LOCK TABLES `material_device_relations` WRITE;
/*!40000 ALTER TABLE `material_device_relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `material_device_relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `material_mold_relations`
--

DROP TABLE IF EXISTS `material_mold_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `material_mold_relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `material_id` int NOT NULL,
  `mold_id` int NOT NULL,
  `relation_type` varchar(50) DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT '0',
  `weight` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `cycle_time` int DEFAULT '0',
  `output_per_cycle` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_material_mold` (`material_id`,`mold_id`,`relation_type`),
  KEY `fk_mmr_mold` (`mold_id`),
  CONSTRAINT `fk_mmr_material` FOREIGN KEY (`material_id`) REFERENCES `materials` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mmr_mold` FOREIGN KEY (`mold_id`) REFERENCES `molds` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_mold_relations`
--

LOCK TABLES `material_mold_relations` WRITE;
/*!40000 ALTER TABLE `material_mold_relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `material_mold_relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `material_purchase_requests`
--

DROP TABLE IF EXISTS `material_purchase_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `material_purchase_requests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `request_no` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `material_id` int NOT NULL,
  `supplier_id` int DEFAULT NULL,
  `quantity` int NOT NULL,
  `unit` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `estimated_price` decimal(10,2) DEFAULT NULL,
  `total_amount` decimal(12,2) DEFAULT NULL,
  `required_date` date NOT NULL,
  `status` enum('draft','submitted','approved','rejected','ordered') COLLATE utf8mb4_unicode_ci DEFAULT 'draft',
  `requester` int DEFAULT NULL,
  `approver` int DEFAULT NULL,
  `purchase_order_id` int DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_req_no` (`request_no`),
  KEY `idx_material` (`material_id`),
  KEY `idx_supplier` (`supplier_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_pr_material` FOREIGN KEY (`material_id`) REFERENCES `materials` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pr_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_purchase_requests`
--

LOCK TABLES `material_purchase_requests` WRITE;
/*!40000 ALTER TABLE `material_purchase_requests` DISABLE KEYS */;
INSERT INTO `material_purchase_requests` VALUES (1,'PR-20260326-001',1,1,100,'张',150.00,15000.00,'2026-04-05','submitted',1,NULL,NULL,NULL,'2026-03-26 06:03:20','2026-03-26 06:03:20'),(2,'PR-20260326-002',3,2,500,'KG',25.00,12500.00,'2026-04-03','approved',1,NULL,NULL,NULL,'2026-03-26 06:03:20','2026-03-26 06:03:20');
/*!40000 ALTER TABLE `material_purchase_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `material_requirements`
--

DROP TABLE IF EXISTS `material_requirements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `material_requirements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `requirement_no` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `production_order_id` int DEFAULT NULL,
  `material_id` int NOT NULL,
  `required_quantity` int NOT NULL,
  `planned_quantity` int DEFAULT '0',
  `purchased_quantity` int DEFAULT '0',
  `stocked_quantity` int DEFAULT '0',
  `unit` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `requirement_date` date NOT NULL,
  `delivery_date` date DEFAULT NULL,
  `status` enum('pending','partial','fulfilled','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `priority` enum('low','medium','high','urgent') COLLATE utf8mb4_unicode_ci DEFAULT 'medium',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_by` int DEFAULT NULL,
  `approved_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_req_no` (`requirement_no`),
  KEY `idx_material` (`material_id`),
  KEY `idx_order` (`production_order_id`),
  KEY `idx_date` (`requirement_date`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_requirements`
--

LOCK TABLES `material_requirements` WRITE;
/*!40000 ALTER TABLE `material_requirements` DISABLE KEYS */;
INSERT INTO `material_requirements` VALUES (1,'REQ-20260326-001',NULL,1,50,0,0,0,'张','2026-03-28',NULL,'pending','high',NULL,NULL,NULL,'2026-03-26 06:03:20','2026-03-26 06:03:20'),(2,'REQ-20260326-002',NULL,2,30,0,0,0,'张','2026-03-28',NULL,'pending','medium',NULL,NULL,NULL,'2026-03-26 06:03:20','2026-03-26 06:03:20'),(3,'REQ-20260326-003',NULL,3,200,0,0,0,'KG','2026-03-30',NULL,'pending','medium',NULL,NULL,NULL,'2026-03-26 06:03:20','2026-03-26 06:03:20');
/*!40000 ALTER TABLE `material_requirements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `material_requisitions`
--

DROP TABLE IF EXISTS `material_requisitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `material_requisitions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `requisition_no` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `material_id` int NOT NULL,
  `warehouse_id` int NOT NULL,
  `quantity` int NOT NULL,
  `unit` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purpose` enum('production','maintenance','sample','return','scrap') COLLATE utf8mb4_unicode_ci DEFAULT 'production',
  `production_order_id` int DEFAULT NULL,
  `department_id` int DEFAULT NULL,
  `requester` int DEFAULT NULL,
  `approver` int DEFAULT NULL,
  `issued_by` int DEFAULT NULL,
  `status` enum('pending','approved','issued','rejected','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `requisition_date` date NOT NULL,
  `issue_date` date DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_req_no` (`requisition_no`),
  KEY `idx_material` (`material_id`),
  KEY `idx_warehouse` (`warehouse_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_rq_material` FOREIGN KEY (`material_id`) REFERENCES `materials` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rq_warehouse` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_requisitions`
--

LOCK TABLES `material_requisitions` WRITE;
/*!40000 ALTER TABLE `material_requisitions` DISABLE KEYS */;
INSERT INTO `material_requisitions` VALUES (1,'RQ-20260326-001',1,1,20,'张','production',NULL,NULL,1,NULL,NULL,'issued','2026-03-25',NULL,NULL,'2026-03-26 06:03:20','2026-03-26 06:03:20'),(2,'RQ-20260326-002',3,1,100,'KG','production',NULL,NULL,1,NULL,NULL,'approved','2026-03-26',NULL,NULL,'2026-03-26 06:03:20','2026-03-26 06:03:20');
/*!40000 ALTER TABLE `material_requisitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `material_scheduling_ext`
--

DROP TABLE IF EXISTS `material_scheduling_ext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `material_scheduling_ext` (
  `id` int NOT NULL AUTO_INCREMENT,
  `material_id` int NOT NULL,
  `default_mold_id` int DEFAULT NULL,
  `scheduling_date` date NOT NULL,
  `planned_quantity` int DEFAULT '0',
  `actual_quantity` int DEFAULT '0',
  `status` enum('pending','in_progress','completed','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `priority` enum('low','medium','high','urgent') COLLATE utf8mb4_unicode_ci DEFAULT 'medium',
  `source_warehouse_id` int DEFAULT NULL,
  `target_warehouse_id` int DEFAULT NULL,
  `transporter` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scheduled_by` int DEFAULT NULL,
  `approved_by` int DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `default_device_id` int DEFAULT NULL COMMENT '默认设备 ID',
  PRIMARY KEY (`id`),
  KEY `idx_material` (`material_id`),
  KEY `idx_date` (`scheduling_date`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_sched_material` FOREIGN KEY (`material_id`) REFERENCES `materials` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_scheduling_ext`
--

LOCK TABLES `material_scheduling_ext` WRITE;
/*!40000 ALTER TABLE `material_scheduling_ext` DISABLE KEYS */;
INSERT INTO `material_scheduling_ext` VALUES (1,1,NULL,'2026-03-27',50,0,'pending','high',1,2,NULL,1,NULL,NULL,'2026-03-26 06:03:21','2026-03-26 06:03:21',NULL),(2,3,NULL,'2026-03-28',200,0,'pending','medium',1,2,NULL,1,NULL,NULL,'2026-03-26 06:03:21','2026-03-26 06:03:21',NULL);
/*!40000 ALTER TABLE `material_scheduling_ext` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `material_stock`
--

DROP TABLE IF EXISTS `material_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `material_stock` (
  `id` int NOT NULL AUTO_INCREMENT,
  `material_id` int NOT NULL,
  `warehouse_id` int NOT NULL,
  `location_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `batch_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` int NOT NULL DEFAULT '0',
  `locked_quantity` int DEFAULT '0',
  `unit_cost` decimal(10,2) DEFAULT NULL,
  `production_date` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `stock_status` enum('normal','low','out','expired') COLLATE utf8mb4_unicode_ci DEFAULT 'normal',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_material` (`material_id`),
  CONSTRAINT `fk_stock_material` FOREIGN KEY (`material_id`) REFERENCES `materials` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_stock`
--

LOCK TABLES `material_stock` WRITE;
/*!40000 ALTER TABLE `material_stock` DISABLE KEYS */;
INSERT INTO `material_stock` VALUES (1,1,1,'WH-RM-001-A-01','BATCH-20260101-001',150,0,150.00,NULL,NULL,'normal','2026-03-26 05:57:19','2026-03-26 05:57:19'),(2,2,1,'WH-RM-001-A-02','BATCH-20260105-001',200,0,120.00,NULL,NULL,'normal','2026-03-26 05:57:19','2026-03-26 05:57:19'),(3,3,1,'WH-RM-001-B-01','BATCH-20260110-001',800,0,25.00,NULL,NULL,'normal','2026-03-26 05:57:19','2026-03-26 05:57:19');
/*!40000 ALTER TABLE `material_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `material_stock_adjustments`
--

DROP TABLE IF EXISTS `material_stock_adjustments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `material_stock_adjustments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `adjustment_no` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `material_id` int NOT NULL,
  `warehouse_id` int NOT NULL,
  `location_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `batch_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `old_quantity` int DEFAULT NULL,
  `new_quantity` int DEFAULT NULL,
  `adjustment_quantity` int DEFAULT NULL,
  `adjustment_type` enum('increase','decrease','correction','transfer') COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` enum('damage','loss','return','correction','inventory_check','other') COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference_no` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `adjusted_by` int DEFAULT NULL,
  `approved_by` int DEFAULT NULL,
  `adjustment_date` date NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_adj_no` (`adjustment_no`),
  KEY `idx_material` (`material_id`),
  KEY `idx_warehouse` (`warehouse_id`),
  KEY `idx_date` (`adjustment_date`),
  CONSTRAINT `fk_adj_material` FOREIGN KEY (`material_id`) REFERENCES `materials` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_adj_warehouse` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_stock_adjustments`
--

LOCK TABLES `material_stock_adjustments` WRITE;
/*!40000 ALTER TABLE `material_stock_adjustments` DISABLE KEYS */;
/*!40000 ALTER TABLE `material_stock_adjustments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `material_stocktakes`
--

DROP TABLE IF EXISTS `material_stocktakes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `material_stocktakes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `stocktake_no` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `warehouse_id` int NOT NULL,
  `material_id` int DEFAULT NULL,
  `location_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `batch_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_quantity` int DEFAULT NULL,
  `actual_quantity` int DEFAULT NULL,
  `difference` int DEFAULT NULL,
  `status` enum('pending','in_progress','completed','reviewed') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `stocktake_date` date NOT NULL,
  `stocktaker` int DEFAULT NULL,
  `reviewer` int DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_st_no` (`stocktake_no`),
  KEY `idx_warehouse` (`warehouse_id`),
  KEY `idx_material` (`material_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_st_material` FOREIGN KEY (`material_id`) REFERENCES `materials` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_st_warehouse` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_stocktakes`
--

LOCK TABLES `material_stocktakes` WRITE;
/*!40000 ALTER TABLE `material_stocktakes` DISABLE KEYS */;
/*!40000 ALTER TABLE `material_stocktakes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `materials`
--

DROP TABLE IF EXISTS `materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `materials` (
  `id` int NOT NULL AUTO_INCREMENT,
  `material_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `material_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `material_type` enum('raw_material','semi_finished','finished','auxiliary','packaging') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'raw_material',
  `specification` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `specifications` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PCS',
  `category_id` int DEFAULT NULL,
  `brand` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `manufacturer` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplier_id` int DEFAULT NULL,
  `cost_price` decimal(10,2) DEFAULT NULL,
  `sale_price` decimal(10,2) DEFAULT NULL,
  `min_stock` int DEFAULT '0',
  `max_stock` int DEFAULT NULL,
  `safety_stock` int DEFAULT '0',
  `warehouse_location` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shelf_life` int DEFAULT NULL,
  `storage_condition` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `attachments` json DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_material_code` (`material_code`),
  KEY `idx_material_type` (`material_type`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `materials`
--

LOCK TABLES `materials` WRITE;
/*!40000 ALTER TABLE `materials` DISABLE KEYS */;
INSERT INTO `materials` VALUES (1,'MAT-Steel-001','不锈钢板 304','raw_material','2mm*1220*2440','active','2mm*1220*2440','张',2,'宝钢','上海钢铁',1,150.00,NULL,100,NULL,0,'WH-RM-001-A-01',NULL,NULL,NULL,NULL,1,'2026-03-26 05:57:19','2026-03-26 06:25:55'),(2,'MAT-Steel-002','碳钢板 Q235','raw_material','3mm*1500*3000','active','3mm*1500*3000','张',2,'鞍钢','上海钢铁',1,120.00,NULL,100,NULL,0,'WH-RM-001-A-02',NULL,NULL,NULL,NULL,1,'2026-03-26 05:57:19','2026-03-26 06:25:55'),(3,'MAT-Plastic-001','ABS 塑料颗粒','raw_material','白色/高流动','active','白色/高流动','KG',3,'奇美','杭州塑料',2,25.00,NULL,500,NULL,0,'WH-RM-001-B-01',NULL,NULL,NULL,NULL,1,'2026-03-26 05:57:19','2026-03-26 06:25:55'),(4,'TEST-001','测试物料 - 已修复','raw_material',NULL,'active','','PCS',NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,1,'2026-03-26 12:31:49','2026-03-26 12:50:33'),(6,'GIT-TEST-001','Git 提交测试','finished',NULL,'active','','PCS',NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,1,'2026-03-26 12:41:30','2026-03-26 12:41:30');
/*!40000 ALTER TABLE `materials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_permissions`
--

DROP TABLE IF EXISTS `menu_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `menu_code` varchar(100) NOT NULL COMMENT '菜单代码',
  `menu_name` varchar(100) NOT NULL COMMENT '菜单名称',
  `parent_code` varchar(100) DEFAULT NULL COMMENT '父菜单代码',
  `icon` varchar(50) DEFAULT NULL COMMENT '图标',
  `sort_order` int DEFAULT '0' COMMENT '排序',
  `path` varchar(200) DEFAULT NULL COMMENT '前端路由',
  `is_visible` tinyint(1) DEFAULT '1' COMMENT '是否可见',
  `permission_code` varchar(100) DEFAULT NULL COMMENT '关联权限代码',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `menu_code` (`menu_code`),
  KEY `idx_parent_code` (`parent_code`),
  KEY `idx_menu_code` (`menu_code`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='菜单权限表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_permissions`
--

LOCK TABLES `menu_permissions` WRITE;
/*!40000 ALTER TABLE `menu_permissions` DISABLE KEYS */;
INSERT INTO `menu_permissions` VALUES (1,'dashboard','仪表盘',NULL,'dashboard',0,'/dashboard',1,NULL,'2026-03-26 03:25:12','2026-03-26 03:25:12'),(2,'production','生产管理',NULL,'production',1,'/production',1,NULL,'2026-03-26 03:25:12','2026-03-26 03:25:12'),(3,'quality','质量管理',NULL,'quality-check',2,'/quality',1,NULL,'2026-03-26 03:25:12','2026-03-26 03:25:12'),(4,'equipment','设备管理',NULL,'setting',3,'/equipment',1,NULL,'2026-03-26 03:25:12','2026-03-26 03:25:12'),(5,'inventory','库存管理',NULL,'inventory',4,'/inventory',1,NULL,'2026-03-26 03:25:12','2026-03-26 03:25:12'),(6,'report','报表分析',NULL,'chart',5,'/reports',1,NULL,'2026-03-26 03:25:12','2026-03-26 03:25:12'),(7,'system','系统管理',NULL,'setting',6,'/system',1,NULL,'2026-03-26 03:25:12','2026-03-26 03:25:12'),(8,'production.order','生产工单','production','file-text',1,'/production/orders',1,'production.order.read','2026-03-26 03:25:12','2026-03-26 03:25:12'),(9,'production.task','生产任务','production','task',2,'/production/tasks',1,'production.task.read','2026-03-26 03:25:12','2026-03-26 03:25:12'),(10,'production.plan','生产计划','production','calendar',3,'/production/plans',1,'production.order.read','2026-03-26 03:25:12','2026-03-26 03:25:12'),(11,'quality.inspection','质量检验','quality','check-square',1,'/quality/inspections',1,'quality.inspection.read','2026-03-26 03:25:12','2026-03-26 03:25:12'),(12,'quality.defect','缺陷记录','quality','alert-circle',2,'/quality/defects',1,'quality.defect.read','2026-03-26 03:25:12','2026-03-26 03:25:12'),(13,'equipment.archive','设备档案','equipment','database',1,'/equipment/archives',1,'equipment.read','2026-03-26 03:25:12','2026-03-26 03:25:12'),(14,'equipment.maintenance','维护记录','equipment','tool',2,'/equipment/maintenance',1,'equipment.read','2026-03-26 03:25:12','2026-03-26 03:25:12'),(15,'inventory.stock','库存查询','inventory','package',1,'/inventory/stock',1,'inventory.read','2026-03-26 03:25:12','2026-03-26 03:25:12'),(16,'inventory.inout','出入库','inventory','arrow-right-left',2,'/inventory/inout',1,'inventory.inout.create','2026-03-26 03:25:12','2026-03-26 03:25:12'),(17,'inventory.transfer','调拨','inventory','truck',3,'/inventory/transfer',1,'inventory.transfer','2026-03-26 03:25:12','2026-03-26 03:25:12'),(18,'report.production','生产报表','report','bar-chart',1,'/reports/production',1,'report.production','2026-03-26 03:25:12','2026-03-26 03:25:12'),(19,'report.quality','质量报表','report','pie-chart',2,'/reports/quality',1,'report.quality','2026-03-26 03:25:12','2026-03-26 03:25:12'),(20,'report.equipment','设备报表','report','line-chart',3,'/reports/equipment',1,'report.equipment','2026-03-26 03:25:12','2026-03-26 03:25:12'),(21,'system.user','用户管理','system','users',1,'/system/users',1,'system.user.read','2026-03-26 03:25:12','2026-03-26 03:25:12'),(22,'system.role','角色权限','system','shield',2,'/system/roles',1,'system.role.read','2026-03-26 03:25:12','2026-03-26 03:25:12'),(23,'system.dept','部门管理','system','building',3,'/system/departments',1,'system.user.read','2026-03-26 03:25:12','2026-03-26 03:25:12'),(24,'system.audit','审计日志','system','file-text',4,'/system/audit',1,'system.audit.read','2026-03-26 03:25:12','2026-03-26 03:25:12'),(25,'system.config','系统配置','system','settings',5,'/system/config',1,'system.config.update','2026-03-26 03:25:12','2026-03-26 03:25:12');
/*!40000 ALTER TABLE `menu_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `molds`
--

DROP TABLE IF EXISTS `molds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `molds` (
  `id` int NOT NULL AUTO_INCREMENT,
  `mold_code` varchar(50) NOT NULL,
  `mold_name` varchar(100) NOT NULL,
  `mold_type` varchar(50) DEFAULT NULL,
  `status` enum('available','in_use','maintenance','scrapped') DEFAULT 'available',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_mold_code` (`mold_code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `molds`
--

LOCK TABLES `molds` WRITE;
/*!40000 ALTER TABLE `molds` DISABLE KEYS */;
INSERT INTO `molds` VALUES (1,'MOLD-001','注塑模具 A1','注塑模','available',1,'2026-03-26 06:05:26','2026-03-26 06:05:26');
/*!40000 ALTER TABLE `molds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oqc_inspections`
--

DROP TABLE IF EXISTS `oqc_inspections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oqc_inspections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `inspection_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch_number` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `inspection_date` date NOT NULL,
  `inspector` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `inspection_qty` int NOT NULL,
  `qualified_qty` int NOT NULL,
  `pass_rate` decimal(5,2) DEFAULT NULL,
  `inspection_result` enum('qualified','unqualified','pending') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `status` enum('completed','in_progress','pending') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inspection_id` (`inspection_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oqc_inspections`
--

LOCK TABLES `oqc_inspections` WRITE;
/*!40000 ALTER TABLE `oqc_inspections` DISABLE KEYS */;
INSERT INTO `oqc_inspections` VALUES (1,'OQC-2024-001','B20241228001','Phone Case A','2024-12-28','Inspector Zhao',1000,988,98.80,'qualified','completed',NULL,'2026-01-15 02:26:24','2026-01-15 02:26:24'),(2,'OQC-2024-002','B20241227001','Phone Case B','2024-12-27','Inspector Sun',1200,1176,98.00,'qualified','completed',NULL,'2026-01-15 02:26:24','2026-01-15 02:26:24'),(3,'OQC-2024-003','B20241226001','Charger','2024-12-26','Inspector Zhou',800,784,98.00,'qualified','completed',NULL,'2026-01-15 02:26:24','2026-01-15 02:26:24');
/*!40000 ALTER TABLE `oqc_inspections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permission_code` varchar(100) NOT NULL COMMENT '权限代码',
  `permission_name` varchar(100) NOT NULL COMMENT '权限名称',
  `module` varchar(50) DEFAULT NULL COMMENT '所属模块',
  `action_type` varchar(20) DEFAULT NULL COMMENT '操作类型',
  `description` text COMMENT '权限描述',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permission_code` (`permission_code`),
  KEY `idx_module` (`module`),
  KEY `idx_action_type` (`action_type`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='权限表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'production.order.read','查看生产工单','production','READ','查看生产工单列表和详情','2026-03-26 03:25:12'),(2,'production.order.create','创建生产工单','production','CREATE','创建新的生产工单','2026-03-26 03:25:12'),(3,'production.order.update','修改生产工单','production','UPDATE','修改生产工单信息','2026-03-26 03:25:12'),(4,'production.order.delete','删除生产工单','production','DELETE','删除生产工单','2026-03-26 03:25:12'),(5,'production.order.export','导出生产工单','production','EXPORT','导出生产工单数据','2026-03-26 03:25:12'),(6,'production.order.approve','审批生产工单','production','APPROVE','审批生产工单','2026-03-26 03:25:12'),(7,'production.task.read','查看生产任务','production','READ','查看生产任务','2026-03-26 03:25:12'),(8,'production.task.update','更新生产任务','production','UPDATE','更新生产任务状态','2026-03-26 03:25:12'),(9,'production.task.complete','完成生产任务','production','UPDATE','标记生产任务为完成','2026-03-26 03:25:12'),(10,'quality.inspection.read','查看质量检验','quality','READ','查看质量检验记录','2026-03-26 03:25:12'),(11,'quality.inspection.create','创建质量检验','quality','CREATE','创建质量检验记录','2026-03-26 03:25:12'),(12,'quality.inspection.update','更新质量检验','quality','UPDATE','更新质量检验记录','2026-03-26 03:25:12'),(13,'quality.inspection.approve','审批质量检验','quality','APPROVE','审批质量检验结果','2026-03-26 03:25:12'),(14,'quality.defect.read','查看缺陷记录','quality','READ','查看缺陷记录','2026-03-26 03:25:12'),(15,'quality.defect.create','创建缺陷记录','quality','CREATE','创建缺陷记录','2026-03-26 03:25:12'),(16,'quality.defect.analyze','缺陷分析','quality','UPDATE','进行缺陷分析','2026-03-26 03:25:12'),(17,'equipment.read','查看设备信息','equipment','READ','查看设备档案','2026-03-26 03:25:12'),(18,'equipment.create','创建设备','equipment','CREATE','创建设备档案','2026-03-26 03:25:12'),(19,'equipment.update','更新设备','equipment','UPDATE','更新设备信息','2026-03-26 03:25:12'),(20,'equipment.maintenance.create','创建维护记录','equipment','CREATE','创建设备维护记录','2026-03-26 03:25:12'),(21,'equipment.maintenance.approve','审批维护申请','equipment','APPROVE','审批设备维护申请','2026-03-26 03:25:12'),(22,'inventory.read','查看库存','inventory','READ','查看库存信息','2026-03-26 03:25:12'),(23,'inventory.inout.create','创建出入库','inventory','CREATE','创建出入库记录','2026-03-26 03:25:12'),(24,'inventory.inout.approve','审批出入库','inventory','APPROVE','审批出入库申请','2026-03-26 03:25:12'),(25,'inventory.transfer','库存调拨','inventory','UPDATE','执行库存调拨','2026-03-26 03:25:12'),(26,'inventory.export','导出库存','inventory','EXPORT','导出库存数据','2026-03-26 03:25:12'),(27,'report.production','查看生产报表','report','READ','查看生产报表','2026-03-26 03:25:12'),(28,'report.quality','查看质量报表','report','READ','查看质量报表','2026-03-26 03:25:12'),(29,'report.equipment','查看设备报表','report','READ','查看设备报表','2026-03-26 03:25:12'),(30,'report.export','导出报表','report','EXPORT','导出各类报表','2026-03-26 03:25:12'),(31,'system.user.read','查看用户','system','READ','查看用户列表','2026-03-26 03:25:12'),(32,'system.user.create','创建用户','system','CREATE','创建新用户','2026-03-26 03:25:12'),(33,'system.user.update','修改用户','system','UPDATE','修改用户信息','2026-03-26 03:25:12'),(34,'system.user.delete','删除用户','system','DELETE','删除用户','2026-03-26 03:25:12'),(35,'system.role.read','查看角色','system','READ','查看角色列表','2026-03-26 03:25:12'),(36,'system.role.create','创建角色','system','CREATE','创建新角色','2026-03-26 03:25:12'),(37,'system.role.update','修改角色','system','UPDATE','修改角色权限','2026-03-26 03:25:12'),(38,'system.role.delete','删除角色','system','DELETE','删除角色','2026-03-26 03:25:12'),(39,'system.permission.read','查看权限','system','READ','查看权限列表','2026-03-26 03:25:12'),(40,'system.permission.update','修改权限','system','UPDATE','修改权限配置','2026-03-26 03:25:12'),(41,'system.audit.read','查看审计日志','system','READ','查看审计日志','2026-03-26 03:25:12'),(42,'system.config.update','修改系统配置','system','UPDATE','修改系统配置','2026-03-26 03:25:12');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pqc_inspections`
--

DROP TABLE IF EXISTS `pqc_inspections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pqc_inspections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `inspection_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `production_order` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `inspection_date` date NOT NULL,
  `inspector` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `inspection_qty` int NOT NULL,
  `qualified_qty` int NOT NULL,
  `pass_rate` decimal(5,2) DEFAULT NULL,
  `inspection_result` enum('qualified','unqualified','pending') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `status` enum('completed','in_progress','pending') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inspection_id` (`inspection_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pqc_inspections`
--

LOCK TABLES `pqc_inspections` WRITE;
/*!40000 ALTER TABLE `pqc_inspections` DISABLE KEYS */;
INSERT INTO `pqc_inspections` VALUES (1,'PQC-2024-001','PO-2025-001','Phone Case A','2024-12-28','Inspector Li',500,490,98.00,'qualified','completed',NULL,'2026-01-15 02:26:24','2026-01-15 02:26:24'),(2,'PQC-2024-002','PO-2025-002','Phone Case B','2024-12-27','Inspector Wang',600,594,99.00,'qualified','completed',NULL,'2026-01-15 02:26:24','2026-01-15 02:26:24'),(3,'PQC-2024-003','PO-2025-003','Charger','2024-12-26','Inspector Zhao',400,396,99.00,'qualified','completed',NULL,'2026-01-15 02:26:24','2026-01-15 02:26:24');
/*!40000 ALTER TABLE `pqc_inspections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_operations`
--

DROP TABLE IF EXISTS `process_operations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `process_operations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `route_id` int NOT NULL,
  `operation_seq` int NOT NULL,
  `operation_name` varchar(100) NOT NULL,
  `standard_time` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_route_op` (`route_id`,`operation_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_operations`
--

LOCK TABLES `process_operations` WRITE;
/*!40000 ALTER TABLE `process_operations` DISABLE KEYS */;
INSERT INTO `process_operations` VALUES (1,1,10,'裁剪',30,'2026-03-26 06:05:26','2026-03-26 06:05:26');
/*!40000 ALTER TABLE `process_operations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_routes`
--

DROP TABLE IF EXISTS `process_routes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `process_routes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `route_code` varchar(50) NOT NULL,
  `route_name` varchar(100) NOT NULL,
  `version` varchar(20) DEFAULT '1.0',
  `status` enum('draft','active','obsolete') DEFAULT 'draft',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_route_code` (`route_code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_routes`
--

LOCK TABLES `process_routes` WRITE;
/*!40000 ALTER TABLE `process_routes` DISABLE KEYS */;
INSERT INTO `process_routes` VALUES (1,'ROUTE-001','加工路线 A','1.0','active','2026-03-26 06:05:26','2026-03-26 06:05:26');
/*!40000 ALTER TABLE `process_routes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `production_lines`
--

DROP TABLE IF EXISTS `production_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `production_lines` (
  `id` int NOT NULL AUTO_INCREMENT,
  `line_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `line_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `capacity_per_hour` int DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `line_code` (`line_code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `production_lines`
--

LOCK TABLES `production_lines` WRITE;
/*!40000 ALTER TABLE `production_lines` DISABLE KEYS */;
INSERT INTO `production_lines` VALUES (1,'LINE-001','生产线1','主要生产线，用于产品A生产',100,1,'2026-01-15 02:19:27','2026-01-15 02:19:27'),(2,'LINE-002','生产线2','辅助生产线，用于产品B生产',80,1,'2026-01-15 02:19:27','2026-01-15 02:19:27'),(3,'LINE-003','生产线3','包装生产线',150,1,'2026-01-15 02:19:27','2026-01-15 02:19:27');
/*!40000 ALTER TABLE `production_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `production_orders`
--

DROP TABLE IF EXISTS `production_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `production_orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_number` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `planned_quantity` int NOT NULL,
  `produced_quantity` int DEFAULT '0',
  `qualified_quantity` int DEFAULT '0',
  `defective_quantity` int DEFAULT '0',
  `status` enum('pending','in_progress','completed','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `priority` enum('low','normal','high','urgent') COLLATE utf8mb4_unicode_ci DEFAULT 'normal',
  `production_line_id` int NOT NULL,
  `planned_start_time` datetime NOT NULL,
  `planned_end_time` datetime NOT NULL,
  `actual_start_time` datetime DEFAULT NULL,
  `actual_end_time` datetime DEFAULT NULL,
  `created_by` int NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_number` (`order_number`),
  KEY `production_line_id` (`production_line_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `production_orders_ibfk_1` FOREIGN KEY (`production_line_id`) REFERENCES `production_lines` (`id`),
  CONSTRAINT `production_orders_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `production_orders`
--

LOCK TABLES `production_orders` WRITE;
/*!40000 ALTER TABLE `production_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `production_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quality_inspections`
--

DROP TABLE IF EXISTS `quality_inspections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quality_inspections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `production_order_id` int NOT NULL,
  `inspection_type` enum('incoming','in_process','final') COLLATE utf8mb4_unicode_ci NOT NULL,
  `inspected_quantity` int NOT NULL,
  `qualified_quantity` int NOT NULL,
  `defective_quantity` int NOT NULL,
  `quality_rate` decimal(5,2) GENERATED ALWAYS AS (((`qualified_quantity` / `inspected_quantity`) * 100)) STORED,
  `inspector_id` int NOT NULL,
  `inspection_date` datetime NOT NULL,
  `defect_types` json DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `production_order_id` (`production_order_id`),
  KEY `inspector_id` (`inspector_id`),
  CONSTRAINT `quality_inspections_ibfk_1` FOREIGN KEY (`production_order_id`) REFERENCES `production_orders` (`id`),
  CONSTRAINT `quality_inspections_ibfk_2` FOREIGN KEY (`inspector_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quality_inspections`
--

LOCK TABLES `quality_inspections` WRITE;
/*!40000 ALTER TABLE `quality_inspections` DISABLE KEYS */;
/*!40000 ALTER TABLE `quality_inspections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_menus`
--

DROP TABLE IF EXISTS `role_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_menus` (
  `role_id` int NOT NULL,
  `menu_id` int NOT NULL,
  `can_view` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`role_id`,`menu_id`),
  KEY `idx_role_id` (`role_id`),
  KEY `idx_menu_id` (`menu_id`),
  CONSTRAINT `role_menus_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_menus_ibfk_2` FOREIGN KEY (`menu_id`) REFERENCES `menu_permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='角色菜单关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_menus`
--

LOCK TABLES `role_menus` WRITE;
/*!40000 ALTER TABLE `role_menus` DISABLE KEYS */;
INSERT INTO `role_menus` VALUES (1,1,1,'2026-03-26 03:25:13'),(1,2,1,'2026-03-26 03:25:13'),(1,3,1,'2026-03-26 03:25:13'),(1,4,1,'2026-03-26 03:25:13'),(1,5,1,'2026-03-26 03:25:13'),(1,6,1,'2026-03-26 03:25:13'),(1,7,1,'2026-03-26 03:25:13'),(1,8,1,'2026-03-26 03:25:13'),(1,9,1,'2026-03-26 03:25:13'),(1,10,1,'2026-03-26 03:25:13'),(1,11,1,'2026-03-26 03:25:13'),(1,12,1,'2026-03-26 03:25:13'),(1,13,1,'2026-03-26 03:25:13'),(1,14,1,'2026-03-26 03:25:13'),(1,15,1,'2026-03-26 03:25:13'),(1,16,1,'2026-03-26 03:25:13'),(1,17,1,'2026-03-26 03:25:13'),(1,18,1,'2026-03-26 03:25:13'),(1,19,1,'2026-03-26 03:25:13'),(1,20,1,'2026-03-26 03:25:13'),(1,21,1,'2026-03-26 03:25:13'),(1,22,1,'2026-03-26 03:25:13'),(1,23,1,'2026-03-26 03:25:13'),(1,24,1,'2026-03-26 03:25:13'),(1,25,1,'2026-03-26 03:25:13'),(4,1,1,'2026-03-26 03:25:13'),(4,8,1,'2026-03-26 03:25:13'),(4,9,1,'2026-03-26 03:25:13'),(4,11,1,'2026-03-26 03:25:13'),(4,13,1,'2026-03-26 03:25:13'),(4,14,1,'2026-03-26 03:25:13'),(4,15,1,'2026-03-26 03:25:13'),(4,16,1,'2026-03-26 03:25:13');
/*!40000 ALTER TABLE `role_menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_permissions` (
  `role_id` int NOT NULL,
  `permission_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`role_id`,`permission_id`),
  KEY `idx_role_id` (`role_id`),
  KEY `idx_permission_id` (`permission_id`),
  CONSTRAINT `role_permissions_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_permissions_ibfk_2` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='角色权限关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permissions`
--

LOCK TABLES `role_permissions` WRITE;
/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
INSERT INTO `role_permissions` VALUES (1,1,'2026-03-26 03:25:12'),(1,2,'2026-03-26 03:25:12'),(1,3,'2026-03-26 03:25:12'),(1,4,'2026-03-26 03:25:12'),(1,5,'2026-03-26 03:25:12'),(1,6,'2026-03-26 03:25:12'),(1,7,'2026-03-26 03:25:12'),(1,8,'2026-03-26 03:25:12'),(1,9,'2026-03-26 03:25:12'),(1,10,'2026-03-26 03:25:12'),(1,11,'2026-03-26 03:25:12'),(1,12,'2026-03-26 03:25:12'),(1,13,'2026-03-26 03:25:12'),(1,14,'2026-03-26 03:25:12'),(1,15,'2026-03-26 03:25:12'),(1,16,'2026-03-26 03:25:12'),(1,17,'2026-03-26 03:25:12'),(1,18,'2026-03-26 03:25:12'),(1,19,'2026-03-26 03:25:12'),(1,20,'2026-03-26 03:25:12'),(1,21,'2026-03-26 03:25:12'),(1,22,'2026-03-26 03:25:12'),(1,23,'2026-03-26 03:25:12'),(1,24,'2026-03-26 03:25:12'),(1,25,'2026-03-26 03:25:12'),(1,26,'2026-03-26 03:25:12'),(1,27,'2026-03-26 03:25:12'),(1,28,'2026-03-26 03:25:12'),(1,29,'2026-03-26 03:25:12'),(1,30,'2026-03-26 03:25:12'),(1,31,'2026-03-26 03:25:12'),(1,32,'2026-03-26 03:25:12'),(1,33,'2026-03-26 03:25:12'),(1,34,'2026-03-26 03:25:12'),(1,35,'2026-03-26 03:25:12'),(1,36,'2026-03-26 03:25:12'),(1,37,'2026-03-26 03:25:12'),(1,38,'2026-03-26 03:25:12'),(1,39,'2026-03-26 03:25:12'),(1,40,'2026-03-26 03:25:12'),(1,41,'2026-03-26 03:25:12'),(1,42,'2026-03-26 03:25:12'),(2,1,'2026-03-26 03:25:13'),(2,5,'2026-03-26 03:25:13'),(2,6,'2026-03-26 03:25:13'),(2,7,'2026-03-26 03:25:13'),(2,10,'2026-03-26 03:25:13'),(2,13,'2026-03-26 03:25:13'),(2,14,'2026-03-26 03:25:13'),(2,17,'2026-03-26 03:25:13'),(2,21,'2026-03-26 03:25:13'),(2,22,'2026-03-26 03:25:13'),(2,24,'2026-03-26 03:25:13'),(2,26,'2026-03-26 03:25:13'),(2,27,'2026-03-26 03:25:13'),(2,28,'2026-03-26 03:25:13'),(2,29,'2026-03-26 03:25:13'),(2,30,'2026-03-26 03:25:13'),(2,31,'2026-03-26 03:25:13'),(2,35,'2026-03-26 03:25:13'),(2,39,'2026-03-26 03:25:13'),(2,41,'2026-03-26 03:25:13'),(4,1,'2026-03-26 03:25:13'),(4,2,'2026-03-26 03:25:13'),(4,3,'2026-03-26 03:25:13'),(4,7,'2026-03-26 03:25:13'),(4,8,'2026-03-26 03:25:13'),(4,9,'2026-03-26 03:25:13'),(4,10,'2026-03-26 03:25:13'),(4,11,'2026-03-26 03:25:13'),(4,12,'2026-03-26 03:25:13'),(4,14,'2026-03-26 03:25:13'),(4,15,'2026-03-26 03:25:13'),(4,16,'2026-03-26 03:25:13'),(4,17,'2026-03-26 03:25:13'),(4,18,'2026-03-26 03:25:13'),(4,19,'2026-03-26 03:25:13'),(4,20,'2026-03-26 03:25:13'),(4,22,'2026-03-26 03:25:13'),(4,23,'2026-03-26 03:25:13'),(4,25,'2026-03-26 03:25:13'),(5,10,'2026-03-26 03:25:13'),(5,11,'2026-03-26 03:25:13'),(5,12,'2026-03-26 03:25:13'),(5,13,'2026-03-26 03:25:13'),(5,14,'2026-03-26 03:25:13'),(5,15,'2026-03-26 03:25:13'),(5,16,'2026-03-26 03:25:13'),(6,22,'2026-03-26 03:25:13'),(6,23,'2026-03-26 03:25:13'),(6,24,'2026-03-26 03:25:13'),(6,25,'2026-03-26 03:25:13'),(6,26,'2026-03-26 03:25:13'),(7,17,'2026-03-26 03:25:13'),(7,18,'2026-03-26 03:25:13'),(7,19,'2026-03-26 03:25:13'),(7,20,'2026-03-26 03:25:13'),(7,21,'2026-03-26 03:25:13');
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) NOT NULL COMMENT '角色代码',
  `role_display_name` varchar(100) NOT NULL COMMENT '角色显示名称',
  `description` text COMMENT '角色描述',
  `is_system` tinyint(1) DEFAULT '0' COMMENT '系统角色不可删除',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_name` (`role_name`),
  KEY `idx_role_name` (`role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='角色表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'admin','超级管理员','拥有系统全部权限',1,'2026-03-26 03:25:12','2026-03-26 03:25:12'),(2,'manager','部门经理','管理部门，查看本部门所有数据',1,'2026-03-26 03:25:12','2026-03-26 03:25:12'),(3,'supervisor','主管','查看和编辑本部门数据',1,'2026-03-26 03:25:12','2026-03-26 03:25:12'),(4,'operator','操作员','基础操作权限',1,'2026-03-26 03:25:12','2026-03-26 03:25:12'),(5,'quality_inspector','质检员','质量管理相关权限',1,'2026-03-26 03:25:12','2026-03-26 03:25:12'),(6,'warehouse_keeper','仓管员','库存管理相关权限',1,'2026-03-26 03:25:12','2026-03-26 03:25:12'),(7,'maintenance','维修工','设备维护相关权限',1,'2026-03-26 03:25:12','2026-03-26 03:25:12'),(8,'viewer','只读用户','仅查看权限，不可编辑',1,'2026-03-26 03:25:12','2026-03-26 03:25:12');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `suppliers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `supplier_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_type` enum('manufacturer','trader','service') COLLATE utf8mb4_unicode_ci DEFAULT 'manufacturer',
  `contact_person` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `credit_level` enum('A','B','C','D') COLLATE utf8mb4_unicode_ci DEFAULT 'B',
  `quality_rating` decimal(3,2) DEFAULT '5.00',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_supplier_code` (`supplier_code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES (1,'SUP-001','上海钢铁集团有限公司','manufacturer','陈经理','13900139001','chen@shsteel.com',NULL,'A',5.00,1,'2026-03-26 05:57:19','2026-03-26 05:57:19'),(2,'SUP-002','杭州塑料制品有限公司','manufacturer','刘经理','13900139002','liu@hzplastic.com',NULL,'B',5.00,1,'2026-03-26 05:57:19','2026-03-26 05:57:19'),(3,'TEST-POST-009','测试POST验证9','manufacturer','测试联系人9','13900139006','test9@example.com','测试地址9','A',5.00,1,'2026-03-28 13:03:35','2026-03-28 13:03:35'),(4,'MES-REPORT-20260328','MaxMES 系统优化日报 - 2026年3月28日','service','系统报告','00000000000','report@mes-system.local','系统报告归档','A',5.00,1,'2026-03-28 13:32:47','2026-03-28 13:32:47');
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_roles` (
  `user_id` int NOT NULL,
  `role_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_role_id` (`role_id`),
  CONSTRAINT `user_roles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_roles_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户角色关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` VALUES (1,1,'2026-03-27 06:08:02');
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('admin','manager','operator','quality_inspector') COLLATE utf8mb4_unicode_ci DEFAULT 'operator',
  `department` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department_id` int DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `fk_users_department` (`department_id`),
  CONSTRAINT `fk_users_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','$2a$10$GBAuRAiqWsJXlkqWliiWfOv1GZTrdyamumfKRjFEjDk2.cbyGgwGa','admin@mes.com','系统管理员','admin','IT部门',NULL,1,'2026-04-02 12:38:45','2026-01-15 02:19:27','2026-04-02 04:38:45');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `warehouses`
--

DROP TABLE IF EXISTS `warehouses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `warehouses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `warehouse_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `warehouse_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `warehouse_type` enum('raw_material','finished','transit','virtual') COLLATE utf8mb4_unicode_ci DEFAULT 'raw_material',
  `location` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `manager` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_warehouse_code` (`warehouse_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `warehouses`
--

LOCK TABLES `warehouses` WRITE;
/*!40000 ALTER TABLE `warehouses` DISABLE KEYS */;
INSERT INTO `warehouses` VALUES (1,'WH-RM-001','原材料仓库','raw_material','车间 A-1 楼','张三','13800138001',1,'2026-03-26 05:57:19','2026-03-26 05:57:19'),(2,'WH-FG-001','成品仓库','finished','车间 B-1 楼','李四','13800138002',1,'2026-03-26 05:57:19','2026-03-26 05:57:19');
/*!40000 ALTER TABLE `warehouses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `work_centers`
--

DROP TABLE IF EXISTS `work_centers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `work_centers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `center_code` varchar(50) NOT NULL,
  `center_name` varchar(100) NOT NULL,
  `center_type` varchar(50) DEFAULT NULL,
  `status` enum('available','busy','maintenance','offline') DEFAULT 'available',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_center_code` (`center_code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `work_centers`
--

LOCK TABLES `work_centers` WRITE;
/*!40000 ALTER TABLE `work_centers` DISABLE KEYS */;
INSERT INTO `work_centers` VALUES (1,'WC-A-001','注塑中心 A','注塑','available',1,'2026-03-26 06:05:26','2026-03-26 06:05:26');
/*!40000 ALTER TABLE `work_centers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'mes_system'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-03  2:00:04
